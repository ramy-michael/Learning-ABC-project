var mysql = require("mysql");

var connection = mysql.createConnection({
  host: "localhost",
  port: 3306,

  // Your username
  user: "root",

  // Your password
  password: "root",
  database: "alphabet"
});

connection.connect(function(err) {
  if (err) throw err;
  console.log("connected as id " + connection.threadId);
  connection.end();
});

botton.addEventListener('click', function(){
    var value = document.getElementById('div1').value;
    if (value) {

        addItemToDOM(value);
        document.getElementById('div1').value = '';

        data.todo.push(value);
        dataObjectUpdated();
    }

});
function addItem (value) {
  addItemToDOM(value);
  document.getElementById('item').value = '';

  data.todo.push(value);
  dataObjectUpdated();
}