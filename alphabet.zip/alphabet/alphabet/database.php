<?php
	if(isset($_POST['obj']))
{
	//Convert it to an Associative Array
   $data = json_decode($_POST['obj'], true);
   //echo $_POST['obj'];
   //Save In MySQL
   $conn = new mysqli("localhost", "root", "rootroot", "alphabet");
   if($conn->connect_error){
  	die($conn->connect_error);
   }
   $type = $data['e_type'];
   $target = $data['e_target'];
   $time=$data['e_time'];
   $sql = "insert into storage values('$type', '$target','$time')";
   $conn->query($sql);
   if($conn->affected_rows > 0){
     echo "Inserted Successfully";
  }
   else{
     echo "Sorry: Problem With Insertion Error :". $conn->error;	
   } 
 }
 
 if(isset($_GET['object'])){
  $sql = "Select * from storage"; 
 $conn = new mysqli("localhost", "root", "rootroot", "alphabet");
 if($conn->connect_error){
  	die($conn->connect_error);
   }
 
  if ($result = $conn->query($sql)){
    $rows = array();
    if($result->num_rows > 0){
     while($row = $result->fetch_assoc()){
      array_push($rows, $row);
     }
	 
    echo json_encode($rows);
   }
 }
 else{
  echo "No Data to Retrieve";
 }
}
?>