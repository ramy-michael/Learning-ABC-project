<?php  
$server='localhost';	
$username='root';
$password='rootroot';
$con=mysql_connect($server,$username,$password);
if(!$con)
	die("can not connect to the server $server");
$q=mysql_query('CREATE DATABASE IF NOT EXISTS alphabet',$con);
if(!$q)
	die("failed to create the database");
mysql_select_db('alphabet');
$sql="
CREATE TABLE IF NOT EXISTS storage (
type char(100) NOT NULL,
target char(100) NOT NULL,
time date NOT NULL
)";
$q=mysql_query($sql);
if(!$q)
	echo mysql_error();
?>